
      <nav class="navbar navbar-expand-md navbar-light bg-light" style="background: rgb(255,253,253); background: linear-gradient(0deg, rgba(255,253,253,1) 0%, rgba(180,199,207,1) 100%, rgba(182,206,14,1) 106%);">
      <a class="navbar-brand" href="index.php" style="color : #e63900; font-size: 25px; font-style: bold; font-family: Times new roman;"><b>BANK OF BARODA</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar" style="">
            <ul class="navbar-nav ml-auto" style="background: rgb(222,204,212);
background: radial-gradient(circle, rgba(222,204,212,1) 0%, rgba(148,187,233,1) 100%); border-radius: 4px;">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color : #000080;"><b>Home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="createuser.php" style="color :  #000080;"><b>Create User</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfermoney.php" style="color :  #000080;"><b>View Customer</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php" style="color :  #000080;"><b>Transaction History</b></a>
              </li>
          </div>
       </nav>
